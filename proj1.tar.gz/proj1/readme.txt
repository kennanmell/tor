Project 1 of the tor61 assignment implements an address registration agent and client.
This project was tested against the server at cse461.cs.washington.edu:46101

Team Members:
Bryan Yue (byue@uw.edu, S# 1370562)
Kennan Mell (kmell96@uw.edu, S# 1438696)
